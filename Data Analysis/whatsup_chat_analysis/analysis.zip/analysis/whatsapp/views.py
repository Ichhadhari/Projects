import re
from urlextract import URLExtract
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from django.contrib.staticfiles import finders
from collections import Counter
import emoji
import io
import base64
import matplotlib.pyplot as plt
from django.shortcuts import render
from wordcloud import WordCloud



user_list=[]
main_df = pd.DataFrame()
# Create your views here.
def demo(request):
    global main_df
    global user_list
    if request.method == 'POST':
        if 'file' in request.FILES:
            uploaded_file = request.FILES['file']
            data = uploaded_file.read().decode('utf-8')
            pattern = '\d{1,2}/\d{1,2}/\d{2,4},\s\d{1,2}:\d{2}\s-\s'

            messages = re.split(pattern, data)[1:]
            dates = re.findall(pattern, data)

            if len(dates) == 0:
                pattern = r'(\d{2}/\d{2}/\d{2}, \d{1,2}:\d{2}\s*[ap]m) - (.*)'
                matches = re.findall(pattern, data)
                for match in matches:
                    dates.append(match[0])
                    messages.append(match[1])
            df = pd.DataFrame({'user_message': messages, 'message_date': dates})

            # Convert message_date type
            df['message_date'] = pd.to_datetime(df['message_date'], format='%d/%m/%y, %I:%M %p')

            # Rename columns
            df.rename(columns={'message_date': 'date'}, inplace=True)

            users = []
            messages = []
            for message in df['user_message']:
                entry = re.split('([\w\W]+?):\s', message)
                if entry[1:]:  # user name
                    users.append(entry[1])
                    messages.append(" ".join(entry[2:]))
                else:
                    users.append('group_notification')
                    messages.append(entry[0])

            df['user'] = users
            df['message'] = messages
            df.drop(columns=['user_message'], inplace=True)
            df['only_date'] = df['date'].dt.date
            df['year'] = df['date'].dt.year
            df['month_num'] = df['date'].dt.month
            df['month'] = df['date'].dt.month_name()
            df['day'] = df['date'].dt.day
            df['day_name'] = df['date'].dt.day_name()
            df['hour'] = df['date'].dt.hour
            df['minute'] = df['date'].dt.minute
            period = []
            for hour in df[['day_name', 'hour']]['hour']:
                if hour == 23:
                    period.append(str(hour) + "-" + str('00'))
                elif hour == 0:
                    period.append(str('00') + "-" + str(hour + 1))
                else:
                    period.append(str(hour) + "-" + str(hour + 1))

            df['period'] = period
            main_df  = df.copy()
            df_html = df.sample(10).to_html()
            user_list = main_df['user'].unique().tolist()
            print(user_list)
            user_list.remove('group_notification')
            user_list.sort()

            # Insert 'overall' at position
            user_list.insert(0, 'Overall')
            context = { 'df_html' : df_html,
                        'main_df ' : main_df,
                        'user_list':user_list

            }
            return render(request, 'whatsapp/browse.html', context)
        elif 'user_selection' in request.POST:
            selected_option = request.POST.get('user_selection')
            print(selected_option)
            num_messages, words, num_media_messages, num_links = fetch_stats(selected_option, main_df)
            print(num_messages, words, num_media_messages, num_links)

            df_html = main_df.sample(10).to_html()
            # Remove the value from the list
            user_list.remove(selected_option)

            #data = [go.Bar(x=['A', 'B', 'C'], y=[10, 15, 7])]
            #layout = go.Layout(title='My Chart')
            #fig = go.Figure(data=data, layout=layout)
            #chart = fig.to_html(full_html=False)
            timeline = monthly_timeline(selected_option, main_df)
            print(timeline['time'],timeline['message'])
            fig1 = go.Figure(data=go.Scatter(x=timeline['time'], y=timeline['message']))
            fig1.update_layout(title='Monthly Timeline', xaxis_title='Month', yaxis_title='No. of Messages')
            chart = fig1.to_html(full_html=False)

            daily_timeline_chart2 = daily_timeline(selected_option, main_df)
            fig2 = go.Figure(data=go.Scatter(x=daily_timeline_chart2['only_date'], y=daily_timeline_chart2['message']))
            fig2.update_layout(title='Daily Timeline', xaxis_title='Date', yaxis_title='No. of Messages')
            chart2 = fig2.to_html(full_html=False)

            busy_day = week_activity_map(selected_option, main_df)
            fig3 = go.Figure(data=go.Bar(x=busy_day.index, y=busy_day.values, text=busy_day.values))
            fig3.update_layout(title='Weekly Activity', xaxis_title='Day', yaxis_title='No. of Messages')
            chart3 = fig3.to_html(full_html=False)

            busy_month = month_activity_map(selected_option, main_df)
            fig4 = go.Figure(data=go.Bar(x=busy_month.index, y=busy_month.values, text=busy_month.values))
            fig4.update_layout(title='Month Activity', xaxis_title='Month', yaxis_title='No. of Messages')
            chart4 = fig4.to_html(full_html=False)

            user_heatmap = activity_heatmap(selected_option, main_df)
            # Create the heatmap trace
            heatmap = go.Heatmap(
                x=user_heatmap.columns,
                y=user_heatmap.index,
                z=user_heatmap.values,
                colorscale='Viridis'
            )

            # Create the layout
            layout = go.Layout(
                title='Activity Heatmap',
                xaxis=dict(title='Period'),
                yaxis=dict(title='Day'),
            )

            # Create the figure
            fig5 = go.Figure(data=[heatmap], layout=layout)
            chart5 = fig5.to_html(full_html=False)

            x_busy_users, new_df = most_busy_users(main_df)
            fig6 = go.Figure(data=go.Bar(x=x_busy_users.index, y=x_busy_users.values, text=x_busy_users.values))
            fig6.update_layout(title='Most Busy Users', xaxis_title='user', yaxis_title='No. of Messages')
            chart6 = fig6.to_html(full_html=False)

            new_df_html = new_df.head(16).to_html()

            wordcloud = create_wordcloud(selected_option, main_df)

            most_common_df = most_common_words(selected_option, main_df)
            most_common_df_html = most_common_df.head(16).to_html()
            #emoji_df = emoji_helper(selected_option, main_df)
            #emoji_df = emoji_df.head(16).to_html()
            # Insert the value at the first index
            user_list.insert(0, selected_option)
            context ={ 'df_html' : df_html,
                       'user_list': user_list,
                        'num_messages':num_messages,
                        'words':words,
                        'num_media_messages':num_media_messages,
                        'num_links':num_links,
                        'main_df ': main_df,
                       'chart':chart,
                       'chart2': chart2,
                       'chart3': chart3,
                       'chart4': chart4,
                       'chart5': chart5,
                       'chart6': chart6,
                       'new_df_html':new_df_html,
                       'wordcloud': wordcloud,
                       'most_common_df_html':most_common_df_html,


            }


            return render(request, 'whatsapp/browse.html', context)
    return render(request, 'whatsapp/browse.html')


def upload_file(request):
    if request.method == 'POST':
        uploaded_file = request.FILES['file']
        content = uploaded_file.read().decode('utf-8')
        return render(request, 'whatsapp/file_upload.html', {'content': content})

    return render(request, 'whatsapp/file_upload.html')




def fetch_stats(selected_user,df):
    extract = URLExtract()
    if selected_user != 'Overall':
        df = df[df['user'] == selected_user]

    num_messages = df.shape[0]

    # fetch the total number of words
    words = []
    for message in df['message']:
        words.extend(message.split())

    # fetch number of media messages
    num_media_messages = df[df['message'] == '<Media omitted>'].shape[0]

    # fetch number of links shared
    links = []
    for message in df['message']:
        links.extend(extract.find_urls(message))

    return num_messages,len(words),num_media_messages,len(links)
##############
def monthly_timeline(selected_user,df):

    if selected_user != 'Overall':
        df = df[df['user'] == selected_user]

    timeline = df.groupby(['year', 'month_num', 'month']).count()['message'].reset_index()

    time = []
    for i in range(timeline.shape[0]):
        time.append(timeline['month'][i] + "-" + str(timeline['year'][i]))

    timeline['time'] = time

    return timeline

def daily_timeline(selected_user,df):

    if selected_user != 'Overall':
        df = df[df['user'] == selected_user]

    daily_timeline_chart2 = df.groupby('only_date').count()['message'].reset_index()

    return daily_timeline_chart2

def week_activity_map(selected_user,df):

    if selected_user != 'Overall':
        df = df[df['user'] == selected_user]

    return df['day_name'].value_counts()

def month_activity_map(selected_user,df):

    if selected_user != 'Overall':
        df = df[df['user'] == selected_user]

    return df['month'].value_counts()

def activity_heatmap(selected_user,df):

    if selected_user != 'Overall':
        df = df[df['user'] == selected_user]

    user_heatmap = df.pivot_table(index='day_name', columns='period', values='message', aggfunc='count').fillna(0)

    return user_heatmap

def emoji_helper(selected_user, df):
    if selected_user != 'Overall':
        df = df[df['user'] == selected_user]

    emojis = []
    for message in df['message']:
        message_emojis = emoji.demojize(message)
        emojis.extend([c for c in message_emojis if c.startswith(':') and c.endswith(':')])

    emoji_df = pd.DataFrame(Counter(emojis).most_common(len(Counter(emojis))))

    return emoji_df

def create_wordcloud(selected_user,df):
    file_path = finders.find('stop_hinglish.txt')
    f = open(file_path, 'r')
    stop_words = f.read()

    if selected_user != 'Overall':
        df = df[df['user'] == selected_user]

    temp = df[df['user'] != 'group_notification']
    temp = temp[temp['message'] != '<Media omitted>']

    def remove_stop_words(message):
        y = []
        for word in message.lower().split():
            if word not in stop_words:
                y.append(word)
        return " ".join(y)

    wordcloud  = WordCloud(width=1400,height=1000,min_font_size=10,background_color='white')
    temp['message'] = temp['message'].apply(remove_stop_words)
    wc = wordcloud.generate(temp['message'].str.cat(sep=" "))
    # Generate the word cloud image as a base64-encoded string
    image_stream = io.BytesIO()
    plt.imshow(wc, interpolation='bilinear')
    plt.axis('off')
    plt.savefig(image_stream, format='png')
    image_stream.seek(0)
    encoded_image = base64.b64encode(image_stream.getvalue()).decode('utf-8')

    return encoded_image

def most_busy_users(df):
    x = df['user'].value_counts().head()
    df = round((df['user'].value_counts() / df.shape[0]) * 100, 2).reset_index().rename(
        columns={'index': 'name', 'user': 'percent'})
    return x,df

def most_common_words(selected_user,df):
    file_path = finders.find('stop_hinglish.txt')
    f = open(file_path, 'r')
    stop_words = f.read()

    if selected_user != 'Overall':
        df = df[df['user'] == selected_user]

    temp = df[df['user'] != 'group_notification']
    temp = temp[temp['message'] != '<Media omitted>']

    words = []

    for message in temp['message']:
        for word in message.lower().split():
            if word not in stop_words:
                words.append(word)

    most_common_df = pd.DataFrame(Counter(words).most_common(20))
    return most_common_df

